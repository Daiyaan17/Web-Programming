const path = require('path');
const express = require('express');

const app = express();
const port = process.env.PORT || 3001;

// Parse application/x-www-form-urlencoded form bodies
app.use(express.urlencoded({ extended: true }));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// GET / -> render login form
app.get('/', (req, res) => {
  res.render('index');
});

// POST /form -> validate credentials
app.post('/form', (req, res) => {
  const { name, email } = req.body;
  console.log('Received:', name, email);

  if (name === 'Daiyaan' && email === 'daiyaansheriff@gmail.com') {
    res.send('Login Successful!');
  } else {
    res.status(401).send('Invalid name or email.');
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
