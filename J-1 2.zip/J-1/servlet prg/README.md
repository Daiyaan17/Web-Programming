# Simple Login Form (Express + EJS)

This is a minimal Node.js application using **Express** and **EJS** that renders a login form and validates a single allowed name/email pair on submission.

## Features
- Renders a Bootstrap-styled login page at `/`.
- Accepts POST submissions at `/form`.
- Checks for exact credentials:
  - Name: `Daiyaan`
  - Email: `daiyaansheriff@gmail.com`
- Responds with success text or 401 invalid message.

## Prerequisites
- Node.js 16+ installed (check with `node -v`).

## Install & Run
```bash
cd "servlet prg"
npm init -y
npm install express ejs
node server.js
```
Then open: http://localhost:3001

## Adjusting Credentials
Edit the conditional inside `server.js`:
```js
if (name === 'Daiyaan' && email === 'daiyaansheriff@gmail.com') {
  // success
}
```
Replace with any logic (e.g., compare against a list or database).

## Future Improvements
- Add password hashing & sessions
- Use environment variables for allowed credentials
- Show validation feedback inside the page instead of plain text responses
- Add rate limiting and logging

## License
MIT
